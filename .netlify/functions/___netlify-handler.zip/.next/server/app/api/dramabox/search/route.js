var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/search/route.js")
R.c("server/chunks/[root-of-the-server]__67bc8a4b._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/83c16__next-internal_server_app_api_dramabox_search_route_actions_369f42b1.js")
R.m(1198)
module.exports=R.m(1198).exports
