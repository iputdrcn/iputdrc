var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/trending/route.js")
R.c("server/chunks/[root-of-the-server]__461bb562._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/83c16__next-internal_server_app_api_dramabox_trending_route_actions_77a476d9.js")
R.m(46801)
module.exports=R.m(46801).exports
