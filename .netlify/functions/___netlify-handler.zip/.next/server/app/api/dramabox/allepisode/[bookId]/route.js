var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/allepisode/[bookId]/route.js")
R.c("server/chunks/[root-of-the-server]__b827156b._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/6791b_next_47376a62._.js")
R.c("server/chunks/f9caf_server_app_api_dramabox_allepisode_[bookId]_route_actions_d813400a.js")
R.m(48971)
module.exports=R.m(48971).exports
