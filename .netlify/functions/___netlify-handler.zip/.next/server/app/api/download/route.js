var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/download/route.js")
R.c("server/chunks/[root-of-the-server]__be47bead._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/6c7f9_dramabox-main__next-internal_server_app_api_download_route_actions_7c75cb32.js")
R.m(8816)
module.exports=R.m(8816).exports
