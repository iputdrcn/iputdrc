var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/detail/[bookId]/route.js")
R.c("server/chunks/[root-of-the-server]__6d3e1cba._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/6791b_next_47376a62._.js")
R.c("server/chunks/83c16__next-internal_server_app_api_dramabox_detail_[bookId]_route_actions_439aeac9.js")
R.m(42984)
module.exports=R.m(42984).exports
