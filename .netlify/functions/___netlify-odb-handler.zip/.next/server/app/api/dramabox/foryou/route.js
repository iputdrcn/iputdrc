var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/foryou/route.js")
R.c("server/chunks/[root-of-the-server]__d80fe198._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/83c16__next-internal_server_app_api_dramabox_foryou_route_actions_869b44aa.js")
R.m(86363)
module.exports=R.m(86363).exports
