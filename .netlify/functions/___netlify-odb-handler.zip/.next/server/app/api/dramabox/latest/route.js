var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/latest/route.js")
R.c("server/chunks/[root-of-the-server]__fbacd296._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/83c16__next-internal_server_app_api_dramabox_latest_route_actions_ba6721f4.js")
R.m(4809)
module.exports=R.m(4809).exports
