var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/dramabox/dubindo/route.js")
R.c("server/chunks/[root-of-the-server]__b5aba33a._.js")
R.c("server/chunks/[root-of-the-server]__de7a98dd._.js")
R.c("server/chunks/83c16__next-internal_server_app_api_dramabox_dubindo_route_actions_1b77ef36.js")
R.m(44787)
module.exports=R.m(44787).exports
