module.exports=[19485,(e,o,d)=>{}];

//# sourceMappingURL=83c16__next-internal_server_app_api_dramabox_latest_route_actions_ba6721f4.js.map