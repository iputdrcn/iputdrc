module.exports=[97777,(e,o,d)=>{}];

//# sourceMappingURL=83c16__next-internal_server_app_api_dramabox_foryou_route_actions_869b44aa.js.map