module.exports=[23930,(a,b,c)=>{}];

//# sourceMappingURL=6c7f9_dramabox-main__next-internal_server_app_watch_%5BbookId%5D_page_actions_18806980.js.map