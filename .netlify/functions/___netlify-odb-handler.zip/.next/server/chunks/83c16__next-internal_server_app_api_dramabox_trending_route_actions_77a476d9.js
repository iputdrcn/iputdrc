module.exports=[28452,(e,o,d)=>{}];

//# sourceMappingURL=83c16__next-internal_server_app_api_dramabox_trending_route_actions_77a476d9.js.map