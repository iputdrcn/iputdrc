module.exports=[89564,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_dramabox-main__next-internal_server_app_page_actions_05a383a2.js.map