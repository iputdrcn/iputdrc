module.exports=[4802,(e,o,d)=>{}];

//# sourceMappingURL=83c16__next-internal_server_app_api_dramabox_search_route_actions_369f42b1.js.map