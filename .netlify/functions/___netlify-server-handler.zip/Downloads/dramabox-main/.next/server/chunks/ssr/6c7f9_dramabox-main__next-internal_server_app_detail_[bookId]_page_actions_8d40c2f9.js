module.exports=[4997,(a,b,c)=>{}];

//# sourceMappingURL=6c7f9_dramabox-main__next-internal_server_app_detail_%5BbookId%5D_page_actions_8d40c2f9.js.map