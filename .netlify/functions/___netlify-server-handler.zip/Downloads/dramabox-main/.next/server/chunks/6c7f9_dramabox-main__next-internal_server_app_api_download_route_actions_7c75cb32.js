module.exports=[32632,(e,o,d)=>{}];

//# sourceMappingURL=6c7f9_dramabox-main__next-internal_server_app_api_download_route_actions_7c75cb32.js.map