module.exports=[65394,(e,o,d)=>{}];

//# sourceMappingURL=83c16__next-internal_server_app_api_dramabox_detail_%5BbookId%5D_route_actions_439aeac9.js.map